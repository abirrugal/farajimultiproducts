<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <title><?php echo e(config('app.name')); ?></title>


                              
               

<!-- JavaScript -->
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<!-- CSS -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
<!-- Bootstrap theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>


                           

        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Exo+2&display=swap" rel="stylesheet">

                            

        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap5.css?v=').time()); ?>">

        <link rel="stylesheet" href="<?php echo e(asset('css/custom.css?v=').time()); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/slider.css?v=').time()); ?>">

        <link rel="stylesheet" href="<?php echo e(asset('css/sidemenu.css?v=').time()); ?>">

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />


                             

        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

        <script src="<?php echo e(asset('js/bootstrap5.js')); ?>"></script>

        <script src="<?php echo e(asset('js/app.js')); ?>"></script>



      
    </head>
    <body>

       <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php echo $__env->make('frontend.partials.helpmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

       
       <?php echo $__env->make('frontend.partials.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          
          <main role="main">
<div class="container">


<?php if(session('message')): ?>
  <div class="alert alert-<?php echo e(session('type')); ?> mt-3"><?php echo e(session('message')); ?></div>
<?php endif; ?>
</div>

         
           <?php echo $__env->yieldContent('main'); ?>    

          </main>
    
          <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 <?php echo $__env->yieldContent('before_body'); ?>

    

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/cart.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/sidemenu.js')); ?>" type="text/javascript"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>

 
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>