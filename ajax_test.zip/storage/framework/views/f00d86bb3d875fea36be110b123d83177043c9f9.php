

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="container my-4">
<?php $__env->startSection('title'); ?>
<?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>

<p class="btn-sm m-0">Created : <?php echo e($category->created_at); ?></p>

<div class="card-title h5 ml-2 my-3">Sub-Categories under this Category</div>

<?php if($category->child_category->count()<1): ?>
<li class="list-group-item text-center font-weight-bold h6">There is no Sub-Category in this Category</li> 
<?php endif; ?>

<?php if($category->child_category): ?>

<ul class="list-group ">
<?php $__currentLoopData = $category->child_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <li class="list-group-item"><?php echo e($child->name); ?></li> 



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php endif; ?>



</ul>
</div>



</div>

 
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/categories/show.blade.php ENDPATH**/ ?>