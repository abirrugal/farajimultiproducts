

<div class="">
<nav class="bd-subnavbar py-2" aria-label="Secondary navigation">


    <div class="container-xxl d-flex align-items-md-center ">
     

        <span id="menu-btn" class="btn btn-sm d-flex align-items-center" onclick="openNav()">
        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-list mb-1" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
          </svg><span class="side_menu_title"> All</span>
        </span>

  
      
  
  

  
      </button>
    </div>
  </nav>
</div><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/frontend/partials/helpmenu.blade.php ENDPATH**/ ?>