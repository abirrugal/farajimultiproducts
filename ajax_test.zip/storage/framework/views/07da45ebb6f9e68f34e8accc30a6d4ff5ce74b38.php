

<?php $__env->startSection('sidenav'); ?>
    <?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/backend/index.blade.php ENDPATH**/ ?>