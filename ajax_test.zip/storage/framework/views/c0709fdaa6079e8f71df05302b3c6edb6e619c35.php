<div class="mt-4">
  


 



<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    </div><?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/frontend/partials/footer.blade.php ENDPATH**/ ?>