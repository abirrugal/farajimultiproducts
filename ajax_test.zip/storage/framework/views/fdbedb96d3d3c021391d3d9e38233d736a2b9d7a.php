


<?php $__env->startSection('title'); ?>
Customer's Orders.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="well">
    <h3 class="my-4">Orders List</h3>
  
    <div class="table-responsive">
    <table class="table table-bordered table-condensed">
    
    <thead>
    <tr>
    <th class="h5 p-3">Id</th>
    <th class="h5 p-3">Customer's Name</th>
    <th class="h5 p-3">Customer's Phone No</th>
    <th class="h5 p-3">Customer's City</th>
    <th class="h5 p-3">Action</th>
    </tr>
    </thead>
    
    <tbody>
    
    
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td class="h6"><?php echo e($order->id); ?></td>
    <td class="h5"><?php echo e($order->customer_name); ?></td>
    <td class="h6"><?php echo e($order->customer_phone_number); ?></td>
    <td class="h6"><?php echo e($order->city); ?></td>

    <td class="d-flex justify-content-center align-items-center">
        <a  href="<?php echo e(route('admin.order.show', $order->id)); ?>" class="mt-2 btn btn-info text-white me-3">Details</a>
      <form class="d-inline "  action="<?php echo e(route('admin.order.delete', $order->id)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('Delete'); ?>
      <button type="submit" class="btn btn-danger mt-2">Delete</button>

      </form>

    
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    </tbody>
    
    </table>
    <div class="d-flex justify-content-center align-items-center mb-4 bg-secondary pt-3">
    <?php echo e($orders->links()); ?>

    </div>
    </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/orders/orders.blade.php ENDPATH**/ ?>