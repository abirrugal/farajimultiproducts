




  
<nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3 py-3" href="<?php echo e(route('frontend.product.index')); ?>">E-Ecommerce</a>

  

  <input class="form-control form-control-light w-100" type="text" placeholder="Search" aria-label="Search">


  <ul class="navbar-nav px-3 d-flex flex-row mx-2 justify-content-center align-items-center ">

  


      <?php if(auth()->guard()->guest()): ?>

      <li class="nav-item text-nowrap mx-2">
        <a class="nav-link text-white  " href="#">Sign Up</a>
      </li>
      <li class="nav-item text-nowrap mx-2">
        <a class="nav-link text-white  " href="#">Login</a>
      </li>
  
  <?php endif; ?>


  <?php if(auth()->guard()->check()): ?>

    <li class="nav-item text-nowrap mx-2">
      <a class="nav-link text-white  " href="#"><?php echo e(auth()->user()->name); ?></a>
    </li>
    <li class="nav-item text-nowrap mx-2">
      <a class="nav-link text-white  " href="#">Sign out</a>
    </li>

<?php endif; ?>

<li class="nav-item text-nowrap text-white mx-2">

  <?php
      
$data=[];
$data['cart'] = session('cart')? session('cart'):[];
$totalProducts = array_sum(array_column($data['cart'],'quantity'));
  ?>
 
 <a href="<?php echo e(route('cart.index')); ?>" class="text-white"><i class="fas fa-cart-plus"></i> <span data-route="<?php echo e(route('cart.quantity')); ?>" id="total_cart_items"><?php echo e($totalProducts); ?></span></a>
  
  </li>


  </ul>

</nav>

  






<?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>