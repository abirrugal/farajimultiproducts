


<?php $__env->startSection('title'); ?>
    Customer's List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <ul class="list-group list-group-flush d-flex flex-row flex-wrap">
          <li class="list-group-item"><span class="h6">Name : </span> <?php echo e($customer->name); ?></li>
          <li class="list-group-item"><span class="h6">Email : </span><?php echo e($customer->email); ?></li>
          <li class="list-group-item"><span class="h6">Phone number : </span><?php echo e($customer->phone_number); ?></li>
          <li class="list-group-item"><span class="h6">Status : </span><?php echo e($customer->role_as); ?></li>
          <li class="list-group-item"><button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Change status
          </button></li>
    
         <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
    <form action="">
        <div class="modal-body">
          ...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
    </form>
      </div>
    </div>
  </div>
       
        </ul>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/customers/index.blade.php ENDPATH**/ ?>