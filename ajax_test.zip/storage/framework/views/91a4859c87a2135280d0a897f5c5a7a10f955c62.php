

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    
    


<?php if($errors->any()): ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="alert alert-danger m-4">
 <?php echo e($error); ?>

 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<ul class="nav nav-tabs my-4">
  
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('admin.childcategories')); ?>">Child-Categories List</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="#">Edit Child-Category</a>
    </li>
  
  </ul>



<h3 class="my-3">Edit <?php echo e($category->name); ?></h3>

<form action="<?php echo e(route("admin.childcategory.update", $category->id)); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
  <div class="form-group">
    <label for="category">Child-Category Name</label>
    <input type="text" class="form-control mb-3 mt-2" name="child_category" id="category" value="<?php echo e($category->name); ?>">
  </div>

  <div id="emailHelp" class="mb-2 form-text">Select only if you want to change the Default Subcategory.</div>

  <select select class="form-select" aria-label="Default select example" name="subcategory_id">
    <option  value='no_id'>Select a Subcategory </option>

  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php $__currentLoopData = $category->child_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
  <option  value="<?php echo e($sub->id); ?>"><?php echo e($sub->name); ?></option>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <div class="mb-3">
    <label for="image" class="form-label text-black h6">Banner image for category</label>
    <input type="file" name="image"  class="form-control" id="image" aria-describedby="PriceHelp">
    <div id="emailHelp" class="form-text">Upload Banner image..</div>

  </div>

  

  <button type="submit" class="btn btn-primary btn-block">Edit Sub-Category</button>
</form>

<p class=" mt-3"> <a href="<?php echo e(route('admin.subcategories')); ?>" >Go back to Sub-categories</a>  </p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/categories/child_categories/edit.blade.php ENDPATH**/ ?>