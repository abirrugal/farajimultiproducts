

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    
    


<?php if($errors->any()): ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="alert alert-danger m-4">
 <?php echo e($error); ?>

 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<ul class="nav nav-tabs my-4">
  
  <li class="nav-item">
    <a class="nav-link " href="<?php echo e(route('admin.subcategories')); ?>">Sub-Category List</a>
  </li>

  <li class="nav-item">
    <a class="nav-link active" href="<?php echo e(route('admin.subcategory.new')); ?>">Add SubCategory</a>
  </li>

  
  </ul>



<h3 class="my-3">Add New Sub-Category</h3>

<form action="<?php echo e(route("admin.subcategories")); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="sub-category" class="h6">Sub-Category Name</label>

    <input type="text" class="form-control mb-3" name="sub_category" id="sub_category" value="<?php echo e(old('sub_category')); ?>">
  </div>

  <div class="mb-3">
    <label for="sub_img" class="form-label text-black h6">Banner sub_img for category</label>
    <input type="file" name="sub_img"  class="form-control" id="sub_img" aria-describedby="PriceHelp">
    <div id="emailHelp" class="form-text">Upload Banner image..</div>

  </div>

  <div class="form-group">
    <label for="category" class="h6">Select The Category That Your Sub-Category Belongs To</label>
    <select name="category_id" class="form-control mb-3">
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option  value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <button type="submit" class="btn btn-primary btn-block mt-3">Add Category</button>
</form>

<p class=" mt-3"> <a href="<?php echo e(route('admin.subcategories')); ?>" >Go back to Sub-categories</a>  </p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/categories/sub_categories/sub_new.blade.php ENDPATH**/ ?>