

<?php $__env->startSection('title'); ?>

<div class="d-flex flex-column card justify-content-center align-items-center">
    <div class="" style="width: 18rem;">
    <img height="auto" src="<?php echo e(asset('allfiles/products_image').'/'.$product->image); ?>" class="card-img-top w-100 img-fluid " alt="...">
    </div>
    <div class="card-body">
      <h5 class="card-title"><?php echo e($product->title); ?>'s Details</h5>
    </div>
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="card">
    <div class="card-body h5">
     <span class="font-weight-bold"> Product's Id</span> : <?php echo e($product->id); ?>

    </div>
    <div class="card-body h5">
      <span class="font-weight-bold">  Stock Status</span> : <?php echo e($product->in_stock ===1? 'In Stock' : 'Out Of Stock'); ?>

    </div>
    <div class="card-body h5">
      <span class="font-weight-bold">  Product's Price</span> : BDT <?php echo e(number_format($product->price,2)); ?>

    </div>
    <div class="card-body h5">
      <span class="font-weight-bold">  Discounted Price</span>(<span class="text-muted btn-sm">Price after discount</span>) : <?php echo e($product->sale_price === null? 'Discount unavailable' : $product->sale_price); ?>

    </div>
    <div class="card-body h5">
     <span class="font-weight-bold">   Active Or Inactive </span>: <?php echo e($product->active === 1? 'Active':'Inactive'); ?>

    </div>
    
    <div class="card-body h5">
      <span class="font-weight-bold">  Product Created Date</span> : <?php echo e($product->created_at); ?>

    </div>
    <div class="card-body h5">
     <span class="font-weight-bold">   Product Updated Date</span> : <?php echo e($product->updated_at); ?>

    </div>

    <div class="card-body ">
      <div class="font-weight-bold mb-3">   Description :</div>  <?php echo $product->description; ?>

     </div>
  
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/products/show.blade.php ENDPATH**/ ?>