

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<ul class="nav nav-tabs my-4">
 
      <li class="nav-item">
        <a class="nav-link active" href="<?php echo e(route('admin.subcategories')); ?>">Sub-Category List</a>
      </li>

      <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('admin.subcategory.new')); ?>">Add Sub-Category</a>
      </li>
  
  </ul>
    
<div class="well">
    <h3 class="mb-3">SubCategory List</h3>
    <p>
    <a class="btn btn-success" href="<?php echo e(route('admin.subcategory.new')); ?>">Add Sub-Category</a>
    
    </p>
    <div class="table-responsive">
    <table class="table table-bordered table-condensed">
    
    <thead>
    <tr>
    <th class="h5">Id</th>
    <th class="h5">Sub_category</th>
    <th class="h5">Under_category</th>
    <th class="h5">Action</th>

    </tr>
    </thead>
    
    <tbody>
    

    <?php $__currentLoopData = $allcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
  <td class="h6"><?php echo e($child->id); ?></td>
  <td class="h5"><?php echo e($child->name); ?></td>
  <td class="h5"><?php echo e($child->parent_category->name); ?></td>

  <td class="d-flex justify-content-center align-items-center">
      <a href="<?php echo e(route('admin.subcategory.show', $child->id)); ?>" class="btn btn-info text-white me-3">Details</a>
      <a href="<?php echo e(route('admin.subcategory.edit', $child->id)); ?>" class="btn btn-warning me-3">Edit</a>
    <form class="d-inline" action="<?php echo e(route('admin.subcategory.delete', $child->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('Delete'); ?>
    <button type="submit" class="btn btn-danger">Delete</button>

    </form>
 
  </td>
  </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
    
    </table>
    <div class="d-flex justify-content-center align-items-center mb-4 bg-secondary pt-3">

      
      <?php echo e($allcategories->links()); ?>

      

      </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/categories/sub_categories/sub_categories.blade.php ENDPATH**/ ?>