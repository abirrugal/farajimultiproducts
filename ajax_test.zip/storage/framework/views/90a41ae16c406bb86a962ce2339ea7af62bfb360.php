



<?php $__env->startSection('main'); ?> 


<main>


<?php echo $__env->make('frontend.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 

  <div class="album pb-5 pt-5 pt-lg-0 bg-light">
    <div class="container-fluid">
      <?php 
    $count = 0;
      ?>

       
      
      <div class="product-container">

        
        
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php 
        if($count == 10) break; $count++;
        ?>

        <div class="colj">
          <div class="card shadow-sm d-flex justify-content-center">

            <p class="card-text "> <a class=" text-decoration-none menu_title d-flex justify-content-center align-items-center p-2 pt-3" href="<?php echo e(route('frontend.product.sub_list',$category->slug)); ?>"> <?php echo e($category->name); ?>  </a> </p>


            <div class="d-flex justify-content-center align-items-center">
        <div class="w-sm">
            <a href="<?php echo e(route('frontend.product.sub_list',$category->slug)); ?>"> <img class=" img-fluid rounded product_img" src=" <?php echo e(asset('allfiles/category_image').'/'.$category->banner); ?>" alt="<?php echo e($category->slug); ?>"> </a>

        </div>
          </div>

            <div class="card-body">

            
              <div class="d-flex justify-content-between align-items-center">
                <div class="">
               
                 <a href="<?php echo e(route('frontend.product.sub_list',$category->slug)); ?>"><button type="button" class=" btn btn-sm btn-outline-secondary">Shop now</button></a> 
            
                </div>

                

              </div>
            </div>
          </div>
        </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>

    </div>
  </div>

</main>



  <?php $__env->stopSection(); ?>

<?php $__env->startSection('before_body'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/frontend\home.blade.php ENDPATH**/ ?>