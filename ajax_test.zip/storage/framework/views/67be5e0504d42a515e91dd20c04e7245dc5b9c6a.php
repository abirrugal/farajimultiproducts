

<?php $__env->startSection('main'); ?>
    
<div class="container-md">
<div class="card mb-3 mt-4 p-4 border" style="max-width: 100%;">
    <div class="row no-gutters justify-content-center">
        
      <div class="col-md-5 ">

        <img class="img-thumbnail rounded w-100" src="<?php echo e($product->getFirstMediaUrl()); ?>" alt="<?php echo e($product->slug); ?>">


      </div>

      <div class="col-md-5 ">
        <div class="card-body ml-3">
          <h5 class="card-title basic-title"><?php echo e($product->title); ?></h5>

          <?php if($product->sale_price !== null &&  $product->sale_price > 0): ?>
          <p class="card-text price-title"> BDT <strike><?php echo e($product->price); ?></strike> <br> BDT <?php echo e($product->sale_price); ?></p>
          <?php else: ?>
          <p class="card-text price-title"> BDT <?php echo e($product->price); ?></p>
          <?php endif; ?>

          <div class="font-weight-bold">Description</div>
          <p class="card-text description"><?php echo e($product->description); ?></p>
          <hr>


          <form action="<?php echo e(route('cart.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
            <button type="submit" class="btn  btn-outline-primary">Add to Cart</button>
            
            </form>

          
        </div>
      </div>


    </div>
  </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/frontend/products/show.blade.php ENDPATH**/ ?>