



<?php $__env->startSection('title'); ?>
    Create New Product.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
  <div class="col-12">

    <ul class="nav nav-tabs mb-5">
 
        
         
        <li class="nav-item">
          <a class="nav-link " href="<?php echo e(route('admin.products')); ?>">Products List</a>
        </li>

        <li class="nav-item">
            <a class="nav-link active" href="#">Edit Product</a>
          </li>
      
      
      </ul>

      <?php if($errors->any()): ?>
          
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="alert alert-danger mx-3 p-2"><?php echo e($error); ?></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      <?php endif; ?>


  
    <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
      <div class="mb-3">
        <label for="title" class="form-label text-black h6">Product's Title</label>
        <input type="text" name="title" value="<?php echo e($product->title); ?>" class="form-control" id="title" aria-describedby="emailHelp">
        <div id="emailHelp" class="form-text">Enter your product's name/title here..</div>
      </div>

      <div class="mb-3">
        <label for="description" class="form-label text-black h6">Product's Descriptions</label>

       <textarea name="description" name="description" id="description"><?php echo e($product->description); ?></textarea>
       <div id="emailHelp" class="form-text">Enter your product's descriptions here..</div>

      </div>

      <div class="mb-3">
        <label for="image" class="form-label text-black h6">Product's Image</label>
        <input type="file" name="image"  class="form-control" id="image" aria-describedby="PriceHelp">
        <div id="emailHelp" class="form-text">Upload product's image..</div>

      </div>

      <div class="mb-3">
        <label for="price" class="form-label text-black h6">Product's Price</label>
        <input type="number" name="price" value="<?php echo e($product->price); ?>" class="form-control" id="price" aria-describedby="PriceHelp">
        <div id="emailHelp" class="form-text">Enter your product's Original price..</div>

      </div>

      <div class="mb-3">
        <label for="sprice" class="form-label text-black h6">Product's Sell Price</label>
        <input type="number" name="sprice" value="<?php echo e($product->sale_price); ?>" class="form-control" id="sprice" aria-describedby="PriceHelp">
        <div id="emailHelp" class="form-text">Enter your product's Sell price.</div>

      </div>


<label for="stock_status" class="form-label text-black h6">Product's Stock Status</label>
<div class="mb-3">
      <select select class="form-select" aria-label="Default select example" name="product_status" id="stock_status">

        <option value="1" <?php echo e($product->active=== 1? 'selected' : ''); ?>>Active</option>
        <option value="0" <?php echo e($product->active=== 0? 'selected' : ''); ?>>Inactive</option>

      </select>
    </div>

<label for="stock_status" class="form-label text-black h6">Product's Stock Status</label>
<div class="mb-3">
      <select select class="form-select" aria-label="Default select example" name="stock_status" id="stock_status">

        <option value="1" <?php echo e($product->in_stock===1? 'selected' : ''); ?>>In Stock</option>
        <option value="0" <?php echo e($product->in_stock===0? 'selected' : ''); ?>>Out Of Stock</option>

      </select>
    </div>


<label for="stock_status" class="form-label text-black h6">Select Category</label>
<div class="mb-3">
      <select id="categoryList" class="form-select" aria-label="Default select example" name="category">
        <option>Select a Category</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>" <?php echo e($category->id === $product->category_id? 'selected':''); ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </select>
    </div>

   

<label for="stock_status" class="form-label text-black h6">Select Sub-Category</label>
<div class="mb-2">
      <select id="subcategoryList" select class="form-select" aria-label="Default select example" name="sub_category">
       <option selected  value="">Select a Sub-Category</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->child_category): ?>
        <?php $__currentLoopData = $category->child_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <option value="<?php echo e($child->id); ?>" class='parent-<?php echo e($child->category_id); ?> subcategory'><?php echo e($child->name); ?></option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </select>
    </div>
    <div id="emailHelp" class="form-text">Select a sub-category. this is Optional</div>


    <label for="stock_status" class="form-label text-black h6">Select Child-Category</label>
    <div class="mb-3">
          <select id="childcategoryList" select class="form-select" aria-label="Default select example" name="child_category">
           
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->child_category): ?>
            <?php $__currentLoopData = $category->child_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($sub->child->count()>0): ?>   
            <?php $__currentLoopData = $sub->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($child->id); ?>" class='parent-<?php echo e($child->subcategory_id); ?> childcategory'><?php echo e($child->name); ?></option>
    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
          </select>
        </div>


    <div id="emailHelp" class="form-text">Select a child-category. this is Optional</div>


      <button type="submit" class="btn btn-primary mt-3 w-100">Edit</button>
    </form>

  <script>
          
    CKEDITOR.replace( 'description' );
</script>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('before_body'); ?>

<script>

$('#categoryList').on('change', function () {
    $("#subcategoryList").attr('disabled', false); //enable subcategory select
    $("#subcategoryList").val("");
    $("#childcategoryList").attr('disabled', false); //enable subcategory select
    $("#childcategoryList").val("");
    $(".subcategory").attr('disabled', true); //disable all category option
    $(".subcategory").hide(); //hide all subcategory option
    $(".parent-" + $(this).val()).attr('disabled', false); //enable subcategory of selected category/parent
    $(".parent-" + $(this).val()).show(); 
});

$('#subcategoryList').on('change', function () {
    $("#childcategoryList").attr('disabled', false); //enable subcategory select
    $("#childcategoryList").val("");
    $(".childcategory").attr('disabled', true); //disable all category option
    $(".childcategory").hide(); //hide all subcategory option
    $(".parent-" + $(this).val()).attr('disabled', false); //enable subcategory of selected category/parent
    $(".parent-" + $(this).val()).show(); 
});

</script>
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/products/edit.blade.php ENDPATH**/ ?>