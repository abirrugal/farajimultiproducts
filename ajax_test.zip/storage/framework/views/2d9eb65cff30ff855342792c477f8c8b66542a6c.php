



<?php $__env->startSection('main'); ?> 

<?php echo $__env->make('frontend.partials.heading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <div class="album py-5 bg-light">
    <div class="container">

      <div class="row">
    
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
        <div class="col-md-4 col-lg-3">
          <div class="card mb-4 shadow-sm">

            <a href="<?php echo e(route('frontend.product.show',$product->slug)); ?>" class="w-100"> <img class="img-thumbnail rounded w-100" src="<?php echo e($product->getFirstMediaUrl()); ?>" alt="<?php echo e($product->slug); ?>"/> </a>

            <div class="card-body">

              <p class="card-text"> <a href="<?php echo e(route('frontend.product.show',$product->slug)); ?>"><?php echo e($product->title); ?></a> </p>
          
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">

                 <form data-route="<?php echo e(route('cart.store')); ?>" id="add_cart" method="POST" >
                  <?php echo csrf_field(); ?>
                  
                  <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                  <button class="btn  btn-outline-primary" type="submit">Add to cart</button>                  
                  </form>
                 
                  
                </div>


                
                <div class="text-muted home-price">
                  <?php if($product->sale_price !== null &&  $product->sale_price > 0): ?>
              BDT <strike><?php echo e($product->price); ?></strike> <br> BDT <?php echo e($product->sale_price); ?>

                  <?php else: ?>
                  BDT <?php echo e($product->price); ?>

                 <?php endif; ?>
                </div>
                
           
               
              </div>
            </div>
          </div>
        </div>

        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <div class="d-flex justify-content-center align-items-center border  border-primary pt-3 bg-secondary">
      <?php echo e($products->links()); ?>

      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('before_body'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/frontend\home.blade.php ENDPATH**/ ?>