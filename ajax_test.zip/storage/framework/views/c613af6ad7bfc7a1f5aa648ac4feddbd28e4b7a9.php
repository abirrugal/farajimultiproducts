

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="my-4">
<?php $__env->startSection('title'); ?>
<?php echo e($order->customer_name); ?>'s Order Details.
<?php $__env->stopSection(); ?>

<div class="row">

<div class="col-md-6">
  <h5 class="card-title text-center py-3 border">Customer's Details</h5>

  <ul class="list-group">

    
    <div class="list-group-item d-flex flex-column">
      <div class="title fw-bold">Name : </div>
      <div class="ps-2 "><?php echo e($order->customer_name); ?> </div>
     </div>

    <div class="list-group-item d-flex flex-column">
      <div class="title fw-bold">Phone no : </div>
      <div class="ps-2 "> <?php echo e($order->customer_phone_number); ?> </div>
     </div>
    <div class="list-group-item d-flex flex-column">
      <div class="title fw-bold"> Address : </div>
      <div class="ps-2 "> <?php echo e($order->address); ?> </div>
     </div>
    <div class="list-group-item d-flex flex-column">
      <div class="title fw-bold"> City : </div>
      <div class="ps-2 "> <?php echo e($order->city); ?> </div>
     </div>
    <div class="list-group-item d-flex flex-column">
      <div class="title fw-bold"> Postal code : </div>
      <div class="ps-2 "> <?php echo e($order->postal_code); ?> </div>
     </div>

  </ul>
  </div>



  <div class="col-md-6">
    <h5 class="card-title text-center py-3 border">Order's Details</h5>

    <ul class="list-group">
  
      <div class="list-group-item d-flex">
         <div class="title fw-bold"> Order's Id : </div>
         <div class="ps-2 "> <?php echo e($order->id); ?> </div>
       </div>
      
      
      <div class="list-group-item d-flex flex-column">
        <div class="title fw-bold">Total amount (BDT) : </div>
        <div class="ps-2 "><?php echo e(number_format($order->total_amount,2)); ?> </div>
       </div>
  
      <div class="list-group-item d-flex flex-column">
        <div class="title fw-bold"> Discount amount (BDT) : </div>
        <div class="ps-2 "><?php echo e(number_format($order->discount_amount,2)); ?></div>
       </div>
      <div class="list-group-item d-flex flex-column">
        <div class="title fw-bold">Paid amount (BDT) : </div>
        <div class="ps-2 "> <?php echo e(number_format($order->paid_amount,2)); ?> </div>
       </div>
      <div class="list-group-item d-flex flex-column">
        <div class="title fw-bold">Payment Status : </div>
        <div class="ps-2 "> <?php echo e($order->payment_status); ?> </div>
       </div>
      <div class="list-group-item d-flex flex-column">
        <div class="title fw-bold">Operational Status : </div>
        <div class="ps-2 "> <?php echo e($order->operational_status); ?> </div>
       </div>
      <div class="list-group-item d-flex flex-column">
        <div class="title fw-bold">Proccessed By : </div>
        <div class="ps-2 "> <?php echo e($order->processed_by); ?> </div>
       </div>
      
       
  
    </ul>
    </div>


    <div class="card">
      <h4 class="card-title text-center py-3 border">Order Product's Details</h4>

      <table class="table">
        <thead>
          <tr class="h5">
            <th scope="col">Products</th>
            <th scope="col">Quantity</th>
            <th scope="col">Price</th>
            
          </tr>
        </thead>
      
        <tbody>
      <?php $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            
            <td class="h6"><?php echo e($orderProduct->product->title); ?></td>
            <td class="h6"><?php echo e($orderProduct->quantity); ?></td>
            <td class="h6"><?php echo e(number_format($orderProduct->price,2)); ?></td>
            
          </tr>
     
      
      
      
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      </tbody>
    </table>
      
       <div class="card-body h5 d-flex justify-content-center me-4">
        <span class="font-weight-bold ">Total Amount (BDT) :&nbsp; </span> <span class="me-3"><?php echo e(number_format($order->total_amount,2)); ?></span>
      </div>
      
        </div>





  </div>
  </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/orders/show.blade.php ENDPATH**/ ?>