

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<ul class="nav nav-tabs my-4">
 
      <li class="nav-item">
        <a class="nav-link active" href="<?php echo e(route('admin.subcategories')); ?>">Category List</a>
      </li>

      <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('admin.subcategory.new')); ?>">Add SubCategory</a>
      </li>
  
  </ul>
    
<div class="well">
    <h3 class="mb-3">SubCategory List</h3>
    <p>
    <a class="btn btn-success" href="<?php echo e(route('admin.subcategory.new')); ?>">Add SubCategory</a>
    
    </p>
    <div class="table-responsive">
    <table class="table table-bordered table-condensed">
    
    <thead>
    <tr>
    <th>Id</th>
    <th>Sub_category</th>
    <th>Slug</th>
    <th>Action</th>
    </tr>
    </thead>
    
    <tbody>
    

    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <tr>
    <td><?php echo e($category->id); ?></td>
    <td><?php echo e($category->name); ?></td>
    <td><?php echo e($category->slug); ?></td>
    <td>
        <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" class="btn btn-info text-white mr-3">Details</a>
        <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" class="btn btn-warning mr-3">Edit</a>
      <form class="d-inline" action="<?php echo e(route('admin.category.delete', $category->id)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('Delete'); ?>
      <button type="submit" class="btn btn-danger">Delete</button>

      </form>
   
    </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
    
    </table>
    <div class="d-flex justify-content-center align-items-center mb-4 bg-secondary pt-3">
      <?php echo e($subcategories->links()); ?>

      </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/backend/categories/sub_categories/sub_categories.blade.php ENDPATH**/ ?>