<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\ajax_test\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>