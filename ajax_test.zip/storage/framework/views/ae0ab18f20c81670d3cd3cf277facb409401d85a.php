

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="container my-4">
<?php $__env->startSection('title'); ?>
<?php echo e($subcategory->name); ?>

<?php $__env->stopSection(); ?>

<p class="btn-sm m-0">Created Date : <?php echo e($subcategory->created_at); ?></p>
<p class="btn-sm m-0">Last Update at : <?php echo e($subcategory->updated_at); ?></p>
<p class="btn ">Id : <?php echo e($subcategory->id); ?></p>

<div class="card-title h5 ml-2 my-3">Sub-Categories under this Category</div>

<?php if($subcategory->parent_category->count()<1): ?>
<li class="list-group-item text-center font-weight-bold h6">There is no Category in this Category</li> 

<?php else: ?>
<ul class="list-group ">

    <li class="list-group-item"><?php echo e($subcategory->parent_category->name); ?></li> 

</ul>
<?php endif; ?>

<?php if($subcategory->child_category): ?>

<ul class="list-group ">
<?php $__currentLoopData = $subcategory->child_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <li class="list-group-item"><?php echo e($child->name); ?></li> 



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php endif; ?>



</ul>
</div>



</div>

 
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/categories/child_categories/show.blade.php ENDPATH**/ ?>