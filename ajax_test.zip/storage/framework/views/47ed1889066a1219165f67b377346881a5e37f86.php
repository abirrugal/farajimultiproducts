

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    
    


<?php if($errors->any()): ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="alert alert-danger m-4">
 <?php echo e($error); ?>

 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<ul class="nav nav-tabs my-4">
  
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('admin.categories')); ?>">Categories List</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active" href="#">Add Category</a>
    </li>
  
  </ul>



<h3 class="my-3">Add New Category</h3>

<form action="<?php echo e(route("admin.category.update", $category->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
  <div class="form-group">
    <label for="category">Category Name</label>
    <input type="text" class="form-control" name="category" id="category" value="<?php echo e($category->name); ?>">
  </div>

  

  <button type="submit" class="btn btn-primary btn-block">Edit Category</button>
</form>

<p class=" mt-3"> <a href="<?php echo e(route('admin.categories')); ?>" >Go back to categories</a>  </p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/backend/categories/edit.blade.php ENDPATH**/ ?>