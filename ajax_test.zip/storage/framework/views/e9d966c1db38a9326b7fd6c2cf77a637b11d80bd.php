

<?php $__env->startSection('sidenav'); ?>
<?php echo $__env->make('backend.layouts.partials.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    
    


<?php if($errors->any()): ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="alert alert-danger m-4">
 <?php echo e($error); ?>

 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<ul class="nav nav-tabs my-4">
  
  <li class="nav-item">
    <a class="nav-link " href="<?php echo e(route('admin.childcategories')); ?>">Child-Category List</a>
  </li>

  <li class="nav-item">
    <a class="nav-link active" href="<?php echo e(route('admin.childcategory.new')); ?>">Add Child-Category</a>
  </li>
  
  </ul>



<h3 class="my-3">Add New Child-Category</h3>

<form action="<?php echo e(route("admin.childcategories")); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="sub-category" class="h6">Child-Category Name</label>

    <input type="text" class="form-control mb-3" name="child_category" id="child_category" value="<?php echo e(old('child_category')); ?>">
  </div>

  <div class="mb-3">
    <label for="image" class="form-label text-black h6">Banner image for category</label>
    <input type="file" name="image"  class="form-control" id="image" aria-describedby="PriceHelp">
    <div id="emailHelp" class="form-text">Upload Banner image..</div>

  </div>

  <div class="form-group">
    <label for="category" class="h6">Select The Sub-Category That Your Child-Category Belongs To</label>
    <select name="subcategory_id" class="form-control mb-3">
<?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option  value="<?php echo e($sub_category->id); ?>"><?php echo e($sub_category->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <button type="submit" class="btn btn-primary btn-block mt-3">Add child-Category</button>
</form>

<p class=" mt-3"> <a href="<?php echo e(route('admin.childcategories')); ?>" >Go back to child-categories</a>  </p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_test\resources\views/backend/categories/child_categories/new.blade.php ENDPATH**/ ?>