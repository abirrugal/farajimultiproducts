<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name')); ?></title>


                              
               

<!-- JavaScript -->
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<!-- CSS -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
<!-- Bootstrap theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>


                           

        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Exo+2&display=swap" rel="stylesheet">

                            

        <link rel="stylesheet" href="<?php echo e(asset('css/all.css?v=').time()); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/custom.css?v=').time()); ?>">

                             
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />        
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>

      
    </head>
    <body>

       <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
          <main role="main">
<div class="container">


<?php if(session('message')): ?>
  <div class="alert alert-<?php echo e(session('type')); ?> mt-3"><?php echo e(session('message')); ?></div>
<?php endif; ?>
</div>

         
           <?php echo $__env->yieldContent('main'); ?>    

          </main>
    
          <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <script src="<?php echo e(asset('js/cart.js')); ?>"></script>

 <?php echo $__env->yieldContent('before_body'); ?>

    

       
      
 
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\electro-ecommerce\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>