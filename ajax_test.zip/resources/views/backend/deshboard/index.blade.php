@extends('backend.layouts.admin_layouts')

@section('sidenav')
    @include('backend.layouts.partials.side_menu')
@endsection