@extends('backend.layouts.admin_layouts')


@section('title')
    Create New Product.
@endsection

@section('main')

@endsection