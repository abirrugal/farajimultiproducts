

<div class="">
<nav class="bd-subnavbar py-2" aria-label="Secondary navigation">


    <div class="container-xxl d-flex align-items-md-center ">
     

        <span id="menu-btn" class="btn btn-sm d-flex align-items-center" onclick="openNav()">
        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-list mb-1" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
          </svg><span class="side_menu_title"> All</span>
        </span>

  
      {{-- <div class="dropdown ms-3">
    <button class="btn btn-bd-light dropdown-toggle" id="bd-versions" data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
      <span class="d-none d-lg-inline">Bootstrap</span> v5.0
    </button>
    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="bd-versions">
      <li><a class="dropdown-item current" aria-current="true" href="/docs/5.0/">Latest (5.0.x)</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="https://getbootstrap.com/docs/4.6/">v4.6.x</a></li>
      <li><a class="dropdown-item" href="https://getbootstrap.com/docs/3.4/">v3.4.1</a></li>
      <li><a class="dropdown-item" href="https://getbootstrap.com/2.3.2/">v2.3.2</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="/docs/versions/">All versions</a></li>
    </ul>
  </div> --}}
  
  

  
      </button>
    </div>
  </nav>
</div>