<section class="jumbotron text-center">
    <div class="container">
      <h1>Electro Ecommerce</h1>
      <p class="lead text-muted">Buy Anything From Our Website.</p>
      <p>
        <a href="#" class="btn btn-primary my-2">Main call to action</a>
        <a href="#" class="btn btn-secondary my-2">Secondary action</a>
      </p>
    </div>
  </section>